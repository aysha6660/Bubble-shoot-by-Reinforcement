import pygame
import random
import math
import torch
import torch.nn as nn


WIDTH, HEIGHT = 600, 600
BALL_RADIUS = 50
SHOOTER_RADIUS = 10
FPS = 90



def get_random_color():
        return (
            random.randint(50, 255),  # Red
            random.randint(50, 255),  # Green
            random.randint(50, 255),  # Blue
        )

BALL_COLOR = get_random_color()
SHOOTER_COLOR = (255, 255, 255)



class Ball:

    def __init__(self, x, y, speed):
        self.x = x
        self.y = y
        self.speed = speed
        self.radius = BALL_RADIUS

    def update_position(self):
        self.y += self.speed

    def draw_ball(self, screen):
        pygame.draw.circle(screen, BALL_COLOR, (int(self.x), int(self.y)), self.radius)


class Bullet:
        
        def __init__(self, x, y, dx, dy):
            self.x = x
            self.y = y
            self.dx = dx
            self.dy = dy
            self.radius = 7

        def update_position(self):
            self.x += self.dx
            self.y += self.dy

        def draw_bullet(self, screen):
            pygame.draw.circle(screen, SHOOTER_COLOR, (int(self.x), int(self.y)), self.radius)



class Shooter:

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.angle = random.randint(20, 160)
        self.end_x = self.x + 50 * math.cos(math.radians(self.angle))
        self.end_y = self.y - 50 * math.sin(math.radians(self.angle))

        self.angle_rad = math.radians(self.angle)  



    def rotate_shooter(self, direction):
        if direction == "LEFT" and self.angle<=180:
            self.angle += 1
        elif direction == "RIGHT" and self.angle>=0:
            self.angle -= 1


    def shoot_bullet(self):
        angle_rad = math.radians(self.angle)
        velocity = 6
        return Bullet(self.end_x, self.end_y, velocity * math.cos(angle_rad), -velocity * math.sin(angle_rad))


    def draw_shooter(self, screen):
        self.end_x = self.x + 50 * math.cos(math.radians(self.angle))
        self.end_y = self.y - 50 * math.sin(math.radians(self.angle))
        pygame.draw.line(screen, SHOOTER_COLOR, (self.x, self.y), (self.end_x, self.end_y), 5)
        pygame.draw.line(screen, (255, 0, 0), (self.x, self.y), (self.end_x, self.end_y), 2)  

       
    def get_state_shooter(self,w,h):
        angle_rad = math.radians(self.angle)
        x = self.x + 50 * math.cos(angle_rad) /w 
        y = self.y - 50 * math.sin(angle_rad) / h 
        return [x,y]
    

    def get_state(self,op,w,h):
        if op is None:
            return [0,0]
        x = op.x / w
        y = op.y / h
        return [x,y]
    


    def scan(self,ball,w,h,bullet,dead_ball,bullet_f,bullet_out):
        x,y= self.get_state_shooter(w,h)
        e_x,e_loc = self.get_state(ball,w,h)
        dead_x,dead_loc = self.get_state(dead_ball,w,h)
        bulletf_x,bulletf_y = self.get_state(bullet_f,w,h)
        bullet_x,bullet_y =self.get_state(bullet,w,h)
        bullet_out_x,bullet_out_y = self.get_state(bullet_out,w,h)


        return [x,y,e_x,e_loc,bulletf_x,bulletf_y,dead_x,dead_loc,bullet_x,bullet_y,bullet_out_x,bullet_out_y]
    


    def calculate_optimal_angel (self,ball):
        if ball is None:
            return None
        dx=ball.x-self.x
        dy=ball.y-self.y
        return math.degrees(math.atan2(-dy,dx)) 
    
    
    def check_difference(self,previous_angle, current_angle, optimal_angle):
        previous_difference = abs(previous_angle - optimal_angle)
        current_difference = abs(current_angle - optimal_angle)
        
        if current_difference < previous_difference:
            return True
        else:
            return False

    
    

   

