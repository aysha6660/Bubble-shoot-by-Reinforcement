import pygame as pg
import random
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
import numpy as np
import matplotlib.pyplot as plt
from BrainQ import Brain
from utiltyQ import Ball, Bullet, Shooter
from environment_gameQ import ShootingGame


pg.init()
pg.font.init()
clock = pg.time.Clock()


epsilon = 1.0  
epsilon_min = 0.05
epsilon_decay = 0.999
gamma = 0.99  
alpha = 0.001  
replay_buffer = []
max_buffer_size = 100000
batch_size = 64
target_update_frequency = 1000  


q_network = Brain()  
targetNet = Brain() 
targetNet.load_state_dict(q_network.state_dict()) 
optimizer = torch.optim.Adam(q_network.parameters(), lr=alpha)
loss_fn = torch.nn.MSELoss()


game = ShootingGame()
running = True
total_reward = 0
step_count = 0
rewards_history = []  

def select_action(state, epsilon):
    if random.random() < epsilon:
        return random.randint(0, 2)
    else:
        state_tensor = torch.FloatTensor(state).unsqueeze(0)
        q_network.eval()
        with torch.no_grad():
            q_values = q_network(state_tensor)
        q_network.train()
        return q_values.argmax().item()


def update_q_network():
    if len(replay_buffer) < batch_size:
        return  
    minibatch = random.sample(replay_buffer, batch_size)
    states, actions, rewards, next_states, dones = zip(*minibatch)
    states = torch.FloatTensor(states)
    actions = torch.LongTensor(actions)
    rewards = torch.FloatTensor(rewards)
    next_states = torch.FloatTensor(next_states)
    dones = torch.FloatTensor(dones)
    q_values = q_network(states).gather(1, actions.unsqueeze(1)).squeeze()
    with torch.no_grad():
        next_q_values = targetNet(next_states).max(1)[0]
    target_q_values = rewards + (gamma * next_q_values * (1 - dones))
    loss = loss_fn(q_values, target_q_values)
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()

def update_target_network():
    targetNet.load_state_dict(q_network.state_dict())

def store_experience(state, action, reward, next_state, done):
    if len(replay_buffer) >= max_buffer_size:
        replay_buffer.pop(0)
    replay_buffer.append((state, action, reward, next_state, done))
i=1

while running:
    state = game.shooter.scan(game.balls[0] if len(game.balls) > 0 else None,
            600, 600,
            game.bullets[0] if len(game.bullets) > 0 else None,
            None,None,None)
    
    action = select_action(state, epsilon)
    reward, next_state, done = game.step(action)
    total_reward += reward
    
    store_experience(state, action, reward, next_state, done)
    update_q_network()
    
    step_count += 1
    if step_count % target_update_frequency == 0:
        update_target_network()
    
    if epsilon > epsilon_min:
        epsilon *= epsilon_decay
    
    if done:
        print(f'Episode : {i}')

        print(f'Total Reward: {round((total_reward/10 ),3)}')
        print(f'SCORE : {game.score}')
      

        rewards_history.append(total_reward)  
        total_reward = 0
        game.reset_game()
        i+=1

    game.update()
    
    for event in pg.event.get():
        if event.type == pg.QUIT:
            running = False
    
    pg.display.flip()
    clock.tick(120)

pg.quit()

# PLOTS
plt.figure(figsize=(10, 5))
plt.plot(rewards_history, label='Total Reward per Episode')
plt.xlabel('Episode')
plt.ylabel('Total Reward')
plt.title('Total Reward Over Time')
plt.legend()
plt.show()



