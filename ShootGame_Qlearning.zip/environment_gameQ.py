import pygame
import random
import math
import torch
import torch.nn as nn
import torch.optim as optim
from utiltyQ import Ball, Shooter, Bullet


WIDTH, HEIGHT = 600, 600
BALL_RADIUS = 50
SHOOTER_RADIUS = 10
FPS = 90


def get_random_color():
        # Return a random RGB color
        return (
            random.randint(50, 255),  # Red
            random.randint(50, 255),  # Green
            random.randint(50, 255),  # Blue
        )
BALL_COLOR = get_random_color()
SHOOTER_COLOR = (255, 255, 255)
screen = pygame.display.set_mode((WIDTH, HEIGHT))


def check_collide(obj1,obj2):
        offset_x=obj2.x-obj1.x 
        offset_y=obj2.y-obj1.y 
        return obj1.mask.overlap(obj2.mask,(offset_x,offset_y))!=None 

class ShootingGame:

    def __init__(self):
        self.balls =[]
        self.bullets =[]
        self.shooter = Shooter(WIDTH // 2, HEIGHT - 50)
        self.score=0
        self.main_font = pygame.font.SysFont("conicsans",35)
        self.end=3
        self.wave_length=10
        self.reward=0.0
        self.dead_balls=[]



    
    def createnewball(self):
        for  _ in range(self.wave_length):
            x = random.randint(BALL_RADIUS, WIDTH - BALL_RADIUS)
            y = -(random.randint(100,700))
            speed = 1
            b=Ball(x,y,speed)
            self.balls.append(b)
        self.balls.sort(key=lambda x:x.y,reverse=True)


    def update(self):
        screen.fill((0, 0, 0))
        self.draw_score()

        self.shooter.draw_shooter(screen)
        if self.bullets:
            for bullet in self.bullets:
                bullet.update_position()
                bullet.draw_bullet(screen)
                
                self.bullets.sort(key=lambda x:x.y,reverse=False)


        if self.balls:
            for ball in self.balls:
                ball.update_position()
                ball.draw_ball(screen)
                self.balls.sort(key=lambda x:x.y,reverse=True)
            
        

        pygame.display.update()


    def step(self,action):

        reward=0.0
        pygame.display.update()

        target_ball = self.balls[0] if self.balls else None
        self.balls.sort(key=lambda x:x.y,reverse=True)
        self.bullets.sort(key=lambda x:x.y,reverse=False)


        if len(self.balls)==0 and self.end>0:
            self.createnewball()

        self.balls.sort(key=lambda x:x.y,reverse=True)
        self.bullets.sort(key=lambda x:x.y,reverse=False)
        
        previous_alignment= self.shooter.angle
        if action==0:
            self.shooter.rotate_shooter("LEFT")
            current_alignment = self.shooter.angle

            if target_ball:
                perfect_angel=self.shooter.calculate_optimal_angel(target_ball)

                if self.shooter.check_difference (previous_alignment ,current_alignment,perfect_angel):
                    reward+=10
                else:
                    reward-=10
            
        elif action==1:
            self.shooter.rotate_shooter("RIGHT")
            current_alignment = self.shooter.angle

            if target_ball:
                perfect_angel=self.shooter.calculate_optimal_angel(target_ball)
                if self.shooter.check_difference (previous_alignment ,current_alignment,perfect_angel):
                    reward+=10
                else:
                    reward-=10

        elif action==2:
            self.bullets.append(self.shooter.shoot_bullet())
            current_alignment = self.shooter.angle

            if target_ball:
                perfect_angel=self.shooter.calculate_optimal_angel(target_ball)
                if self.shooter.check_difference (previous_alignment ,current_alignment,perfect_angel):
                    reward+=10
                else:
                    reward-=10

        elif action==3:
            reward-=.1
            pass
        

        self.bullets.sort(key=lambda x:x.y,reverse=False)

        if self.balls is None and self.bullets is None:
            return reward,self.shooter.scan(None,WIDTH,HEIGHT,None,None,None,None),self.end<=0
        
        elif self.balls and self.bullets is None:
            return reward,self.shooter.scan(self.balls[0],WIDTH,HEIGHT,None,None,None,None),self.end<=0
        
        elif self.balls is None and self.bullets:
            return reward,self.shooter.scan(None,WIDTH,HEIGHT,self.bullets[0],None,None,None),self.end<=0
        
        if self.bullets and self.balls:
            for bullet in self.bullets:
                for ball in self.balls:
                    if self.detect_collision2(bullet,ball):

                        reward+=30
                        self.score+=1

                        self.balls.remove(ball)
                        self.balls.sort(key=lambda x:x.y,reverse=True)

                        f =bullet
                        self.bullets.remove(bullet)
                        self.bullets.sort(key=lambda x:x.y,reverse=False)

                        if self.balls:
                            if self.balls[0]==ball:
                                reward+=100
                                
                                 

                        if self.balls and self.bullets:
                            return reward,self.shooter.scan(self.balls[0],WIDTH,HEIGHT,self.bullets[0],ball,f,None),self.end<=0
                        elif self.balls and  self.bullets is None:
                            return reward,self.shooter.scan(self.balls[0],WIDTH,HEIGHT,None,ball,f,None),self.end<=0
                        elif  self.balls  is None and self.bullets:
                            return reward,self.shooter.scan(None,WIDTH,HEIGHT,self.bullets[0],ball,f,None),self.end<=0
                        elif self.balls is None and  self.bullets is None:
                            return reward,self.shooter.scan(None,WIDTH,HEIGHT,None,ball,f,None),self.end<=0
        elif self.bullets:
            return reward,self.shooter.scan(None,WIDTH,HEIGHT,self.bullets[0],None,None),self.end<=0
            
        if self.bullets:
            for bullet in self.bullets:
                if bullet.x < 0 or bullet.x > WIDTH or bullet.y < 0 or bullet.y > HEIGHT:
                        reward-=0.01 
                        self.bullets.remove(bullet)
                        self.bullets.sort(key=lambda x:x.y,reverse=False)

                        if self.balls and self.bullets:
                            return reward,self.shooter.scan(self.balls[0],WIDTH,HEIGHT,self.bullets[0],None,None,bullet),self.end<=0
                        elif self.balls and  self.bullets is None:
                            return reward,self.shooter.scan(self.balls[0],WIDTH,HEIGHT,None,None,None,bullet),self.end<=0
                        elif  self.balls  is None and self.bullets:
                            return reward,self.shooter.scan(None,WIDTH,HEIGHT,self.bullets[0],None,None,bullet),self.end<=0
                        elif self.balls is None and  self.bullets is None:
                            return reward,self.shooter.scan(None,WIDTH,HEIGHT,None,None,None,bullet),self.end<=0
            
        for b in self.balls:
                if b.y > HEIGHT:

                    reward-=50
                    self.end-=1
                    print(f"#OF ATTEMPTS REMAINING {self.end}")
                    self.balls.remove(b)
                    self.balls.sort(key=lambda x:x.y,reverse=True)
                    self.bullets.sort(key=lambda x:x.y,reverse=False)
                    if self.end==0:
                            reward -=100
                    

                    if self.balls and self.bullets:
                        return reward,self.shooter.scan(self.balls[0],WIDTH,HEIGHT,self.bullets[0],None,None,None),self.end<=0
                    elif self.balls and  self.bullets is None:
                        return reward,self.shooter.scan(self.balls[0],WIDTH,HEIGHT,None,None,None,None),self.end<=0
                    elif  self.balls  is None and self.bullets:
                        return reward,self.shooter.scan(None,WIDTH,HEIGHT,self.bullets[0],None,None,None),self.end<=0
                    elif self.balls is None and  self.bullets is None:
                        return reward,self.shooter.scan(None,WIDTH,HEIGHT,None,None,None,None),self.end<=0
                    
        self.balls.sort(key=lambda x:x.y,reverse=True)

        if self.balls:
            self.balls.sort(key=lambda x:x.y,reverse=True)
            if self.balls[0].y > 30 and self.balls[0].y <HEIGHT:
                reward -= (0.001)
            if self.balls and self.bullets:
                return reward,self.shooter.scan(self.balls[0],WIDTH,HEIGHT,self.bullets[0],None, None, None),self.end<=0
            elif self.balls and  self.bullets is None:
                return reward,self.shooter.scan(self.balls[0],WIDTH,HEIGHT,None,None,None,None),self.end<=0
            elif  self.balls  is None and self.bullets:
                return reward,self.shooter.scan(None,WIDTH,HEIGHT,self.bullets[0],None,None,None),self.end<=0
            elif self.balls is None and  self.bullets is None:
                return reward,self.shooter.scan(None,WIDTH,HEIGHT,None,None,None,None),self.end<=0

                    

        if self.balls and self.bullets:
            return reward,self.shooter.scan(self.balls[0],WIDTH,HEIGHT,self.bullets[0],None,  None,None),self.end<=0
        elif self.balls and  self.bullets is None:
            return reward,self.shooter.scan(self.balls[0],WIDTH,HEIGHT,None,None,None,None),self.end<=0
        elif  self.balls  is None and self.bullets:
            return reward,self.shooter.scan(None,WIDTH,HEIGHT,self.bullets[0],None,None,None),self.end<=0
        else:
            return reward,self.shooter.scan(None,WIDTH,HEIGHT,None,None,None,None),self.end<=0

    

    def detect_collision2(self,bullet,ball):
        distance = math.sqrt((bullet.x - ball.x) ** 2 + (bullet.y - ball.y) ** 2)
        if distance <= bullet.radius + ball.radius:
            return True
        else:
            return False


    def get_value(self,reward,ball,bullet):
        if self.balls and self.bullets:
            return reward,self.shooter.scan(self.balls[0],WIDTH,HEIGHT,bullet,None,None),self.end<=0
        elif self.balls and  self.bullets is None:
            return reward,self.shooter.scan(self.balls[0],WIDTH,HEIGHT,None,None,None),self.end<=0
        elif  self.balls  is None and self.bullets:
            return reward,self.shooter.scan(None,WIDTH,HEIGHT,bullet,None,None),self.end<=0
        elif self.balls is None and  self.bullets is None:
            return reward,self.shooter.scan(None,WIDTH,HEIGHT,None,None,None),self.end<=0



    def reset_game(self):
        self.shooter = Shooter(WIDTH // 2, HEIGHT - 50)
        self.bullets.clear()
        self.balls.clear()
        self.score = 0
        self.reward = 0.0
        self.end = 3

    def draw_score(self):
        score_label= self.main_font.render(f"SCORE: {self.score}",1,(255,255,255))
        screen.blit(score_label,(WIDTH -score_label.get_width()-10,50))

    
        
        